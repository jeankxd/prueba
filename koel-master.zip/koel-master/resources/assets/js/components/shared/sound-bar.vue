<template>
  <div class="bars">
    <img src="public/img/bars.gif" alt="Sound bars" height="13" width="auto">
  </div>
</template>

<script>
export default {
  // Since we don't have anything here, let us sing a song instead.
  //
  // "The House Of The Rising Sun"
  // -- by The Animals
  //
  // There is a house in New Orleans
  // They call the Rising Sun
  // And it's been the ruin of many a poor boy
  // And God, I know I'm one
  //
  // My mother was a tailor
  // She sewed my new blue jeans
  // My father was a gamblin' man
  // Down in New Orleans
  //
  // Now the only thing a gambler needs
  // Is a suitcase and trunk
  // And the only time he's satisfied
  // Is when he's on a drunk
  //
  // [Organ Solo]
  //
  // Oh mother, tell your children
  // Not to do what I have done
  // Spend your lives in sin and misery
  // In the House of the Rising Sun
  //
  // Well, I got one foot on the platform
  // The other foot on the train
  // I'm goin' back to New Orleans
  // To wear that ball and chain
  //
  // Well, there is a house in New Orleans
  // They call the Rising Sun
  // And it's been the ruin of many a poor boy
  // And God, I know I'm one.
}
</script>

<style lang="scss" scoped>
.bars {
  width: 28px;
  height: 13px;
  position: relative;
  display: inline-block;
  backface-visibility: hidden;
  margin-bottom: 5px;
}
</style>
