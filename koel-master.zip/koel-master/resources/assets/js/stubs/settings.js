export default {
  media_path: ''
}
