<?php

namespace E2E;

abstract class AllSongsScreenTest extends TestCase
{
    // All we need to test should have been cover in SongListTest class.
}
