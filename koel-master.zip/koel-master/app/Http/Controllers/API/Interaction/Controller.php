<?php

namespace App\Http\Controllers\API\Interaction;

use App\Http\Controllers\Controller as BaseController;

class Controller extends BaseController
{
}
