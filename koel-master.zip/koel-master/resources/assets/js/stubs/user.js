export default {
  id: 0,
  name: '',
  email: '',
  avatar: '',
  is_admin: false
}
