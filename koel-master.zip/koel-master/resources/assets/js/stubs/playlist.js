export default {
  name: '',
  songs: []
}
