@extends('errors.template')

@section('title', 'Service Unavailable')
@section('details', 'Koel will be right back.')
