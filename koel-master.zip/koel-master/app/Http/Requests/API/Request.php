<?php

namespace App\Http\Requests\API;

use App\Http\Requests\Request as BaseRequest;

class Request extends BaseRequest
{
    //
}
