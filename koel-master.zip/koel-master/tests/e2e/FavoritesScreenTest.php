<?php

namespace E2E;

abstract class FavoritesScreenTest extends TestCase
{
    // "Favorites" functionality has been covered in SongListTest
}
