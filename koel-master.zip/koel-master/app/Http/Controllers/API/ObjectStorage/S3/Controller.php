<?php

namespace App\Http\Controllers\API\ObjectStorage\S3;

use App\Http\Controllers\API\ObjectStorage\Controller as BaseController;

class Controller extends BaseController
{
}
