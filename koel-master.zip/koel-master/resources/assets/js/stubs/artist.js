export default {
  id: 0,
  name: '',
  image: null,
  playCount: 0,
  albums: [],
  songs: []
}
